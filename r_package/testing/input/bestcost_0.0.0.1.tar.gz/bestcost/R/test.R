beta1 <- log(1.063)/10
beta2 <-  log(1.031)/10
rr_mult <- exp(beta1*9+beta2*14.5)

beta3 <- log(1.057)/9
beta4 <-  log(1.045)/14.5
rr_mult2 <- exp(beta3*9+beta4*14.5)
